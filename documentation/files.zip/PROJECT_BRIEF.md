# Trailblaze Analytics Platform — Project Brief

**Last updated:** 2026-04-21
**Status:** Active build, day 1
**Owner:** Andrew, Trailblaze Marketing
**Project folder:** `C:\Users\Andrew\Documents\trailblaze-analytics`

---

## Read this first

If you're new to this project (a new AI conversation, a developer joining, or future-you in two months) — read this document end to end before doing anything else. It is the source of truth for what we're building, why, and how.

After this, read in order:
1. `ARCHITECTURE.md` — the system design with diagrams
2. `DECISIONS.md` — the choices we made and why
3. `SCHEMA_SPEC.md` — the database schema spec
4. `RUNBOOK.md` — operational procedures (created later)

---

## The one-paragraph version

Trailblaze Marketing publishes daily PDF market intelligence reports on the iGaming (online gambling) industry. We are building an **analytics platform** that ingests these PDFs (plus external scraped data and proprietary modeled estimates) into a structured database, and exposes the data through a high-end interactive dashboard at `analytics.trailblaze-marketing.com`. The platform is positioned as a Bloomberg-Terminal-for-iGaming product, sold to investment banks, hedge funds, private equity, and operator strategy teams. Its key differentiator is **Trailblaze Beacon™** — proprietary modeled estimates that fill data gaps competitors can't.

---

## Background and context

### The company
Trailblaze Marketing is a Marbella-based marketing consultancy (`trailblaze-marketing.com`). One of their offerings is `Insight Reports` — daily PDF intelligence reports on the iGaming industry. These currently live at `reporting.trailblaze-marketing.com` (a MODX CMS-based portal where clients log in and download PDFs).

### The pain point
The reports are static PDFs. Clients can't search across them, can't compare across time, can't get visualizations, can't model market entry. The data is rich — 2+ years of daily content covering operators, markets, regulators — but it's locked in PDF format with no analytics layer.

### The opportunity
Build an analytics platform that turns those PDFs into a queryable, interactive product. Sell it as SaaS to a defined audience (banks/funds/operators) at $15-30k/seat/year. Existing competitors (H2 Gambling Capital, VIXIO, Eilers & Krejcik, Regulus Partners) all sell PDFs and PowerPoints. None has a modern interactive product. The window is open.

---

## What we're building

### The three buckets

**1. Markets bucket** — by jurisdiction (US states, countries, regions)
- Per-jurisdiction profiles: tax rates, regulatory framework, market structure
- Historical trends (monthly/quarterly), charted from your back-data
- Active web scraping of regulator data for real-time enrichment
- Cross-market comparison
- **Integrated Business Planner** — the killer feature. A BD/manager evaluating market entry can model forecasts based on tax rate, your proprietary KPI estimates, comparables. They can dump their own data in too.

**2. Companies bucket** — entity-level intelligence with three sub-types:
- **B2C Operators** (FanDuel, DraftKings, Entain, Betsson, ATG)
- **Affiliates** (Better Collective, Catena Media, Acroud)
- **B2B / Platforms / Suppliers** (Evolution, Playtech, NetEnt, Aristocrat)

Each entity gets a deep-history snapshot, web-scraped enrichment, cross-entity comparison, stock price integration where listed.

**3. Trailblaze Beacon™** — proprietary modeled estimates (cross-cutting feature, not a separate bucket)
- Where data isn't disclosed, we model it from peer ratios, tax-implied math, stock-price back-solving, etc.
- Branded `Trailblaze Beacon™` and visually flagged everywhere it appears
- Defensible because no competitor has this
- Revenue lever — clients can't replicate this themselves

### Aesthetic / positioning
- Bloomberg Terminal × Linear × Vercel
- Dark mode default
- Dense, professional, monospace numbers, sans-serif prose
- Trailblaze blue (`#2BA8E0`) as accent
- High-end, B2B, premium feel — not a consumer dashboard

---

## The data

### Source 1: Trailblaze's own PDFs
- ~307 historical reports + ~1 new per day
- Live on the existing reporting server: `92.205.179.34`, user `datareporting`, path `/home/datareporting/public_html/assets/files/group1/`
- SSH key for access lives in `archive/datareporting`
- PDFs follow a 7-section template (Executive Summary → Company Insights → Market Deep Dive → Affiliate & Market Benchmarking → Forecast & Strategy → Investment View → Valuation Scenarios)
- Some PDFs are "shells" (empty templates where the source email had no content) — must be detected and flagged
- One PDF can cover multiple entities and multiple markets — the schema is many-to-many
- Sometimes the same quarter is reported in multiple PDFs (report + presentation + trading update) — needs reconciliation

### Source 2: External scrapers (in build)
- US state regulators (NJ DGE, PA PGCB, MI MGCB, CT, IL Gaming Board) — monthly iGaming/OSB data
- Stock market data via yfinance — for any entity with a ticker
- Future: SEC filings, industry trades, social sentiment

### Source 3: Trailblaze Beacon™ (proprietary)
- Modeled estimates where no source has the data
- Methodologies: tax-rate-implied, peer-ratio, stock-price-implied, prior-period extrapolation, composite
- Each estimate has a confidence score and a confidence band
- Audit trail in `beacon_estimates` table — defensible to clients

---

## Architecture (high level)

```
┌─────────────────────────────────────────────────────────────┐
│                  TRAILBLAZE ANALYTICS                       │
└─────────────────────────────────────────────────────────────┘

┌──────────────┐   ┌──────────────┐   ┌──────────────┐
│  PDF parser  │   │   Scrapers   │   │  Beacon™     │
│  (Python +   │   │  (Python +   │   │  engine      │
│   Anthropic) │   │   yfinance,  │   │  (later)     │
│              │   │   BS4)       │   │              │
└──────┬───────┘   └──────┬───────┘   └──────┬───────┘
       │                  │                  │
       └──────────────────▼──────────────────┘
                          │
                  ┌───────▼────────┐
                  │   PostgreSQL   │
                  │  (15 tables,   │
                  │   46 metrics,  │
                  │   73 markets)  │
                  └───────┬────────┘
                          │
                  ┌───────▼────────┐
                  │   Next.js 14   │
                  │   Dashboard    │
                  │   (TypeScript, │
                  │    Tailwind,   │
                  │    Recharts)   │
                  └────────────────┘
```

See `ARCHITECTURE.md` for the full diagram and data flow.

---

## Tech stack (locked decisions)

| Layer | Choice | Why |
|---|---|---|
| Database | PostgreSQL 16 | jsonb, materialized views, full-text search, free, portable |
| Database hosting (prod) | Neon or Supabase | Managed Postgres, generous free tier |
| Backend language | Python 3.13 | Best for PDF + AI work, Anthropic SDK first-class |
| ORM | SQLAlchemy + Alembic | Standard, battle-tested |
| Parser | Claude (Anthropic API) with structured JSON output | LLM is the only thing that handles PDF variability well |
| Backend hosting (prod) | Railway | Cheap, runs Python continuously, easy cron |
| Frontend | Next.js 14 + TypeScript | Industry standard, Vercel-native |
| Styling | Tailwind CSS + shadcn/ui | Fast, dark mode native, customizable |
| Charts | Recharts | React-native, good defaults |
| Tables | TanStack Table | Best dense-grid library |
| Auth | Supabase Auth | Free tier, magic-link out of the box |
| Frontend hosting (prod) | Vercel | Made for Next.js |
| Domain | `analytics.trailblaze-marketing.com` | Subdomain of existing brand |

---

## Status as of 2026-04-21

### ✅ Done
- Project planning, schema design, all major architectural decisions
- 307 PDFs pulled from production server
- PostgreSQL installed locally (Windows native, not Docker — WSL2 issues)
- Full schema migration applied (15 tables)
- Seed data loaded: 9 entity types, 9 sources, 46 metrics, 72 periods, 73 markets, 40 entities
- PDF parser scaffolded with two-pass extraction (classification → extraction)
- Anthropic API key configured (rotated once after accidental exposure — see DECISIONS.md)
- Git initialized, first commit captured
- Schema spec frozen in `SCHEMA_SPEC.md`

### 🔄 In progress (day 1, three Claude Code instances running in parallel)
- **Terminal 1:** Bulk parsing of all 307 PDFs (after fixing parser bugs and expanding dictionaries discovered in test batch)
- **Terminal 2:** Building Next.js frontend in `web/` folder (auth, layout, markets, companies, Beacon™ flagging)
- **Terminal 3:** Building scrapers in `src/trailblaze/scrapers/` (5 US regulators + stock prices via yfinance)

### 📋 Not started
- Trailblaze Beacon™ estimation engine (schema supports it, build deferred)
- Production deployment (Vercel + Neon + Railway)
- Domain DNS setup (`analytics.trailblaze-marketing.com`)
- Methodology page content (legal-defensible writing for the Beacon™ explanation)
- Sales materials, pricing tiers
- Customer pilot program

---

## Open questions / known issues

1. **Auth model:** Decided to keep separate from existing portal (`reporting.trailblaze-marketing.com`). Same users will have two accounts for now. Single sign-on later.
2. **Trailblaze Beacon™ methodology page:** Content not yet written. Needs to be defensible to financial clients.
3. **Pricing not yet set.** Likely $15-30k/seat/year per the original positioning. Needs validation with 3-5 friendly clients before going wide.
4. **Sales/distribution:** No outreach plan yet. Whoever picks this up should reach out to top 10 client targets early.
5. **Brand colors:** Using best-guess hex codes (`#2BA8E0` blue, `#2B2D8E` purple). Real palette needs to come from the Trailblaze designer or a logo extraction.
6. **Some PDFs may need reprocessing** as parser improves and dictionary expands. Reprocessing logic is in place via `parser_version`.

---

## How decisions get made

When in doubt, the principles are (in order):
1. **Ship fast over ship perfect.** Real client feedback beats speculation.
2. **Preserve provenance.** Every value should know where it came from.
3. **Beacon™ is sacred.** It's the moat. Methodology must be airtight.
4. **One person + AI > a team of devs.** Optimize for parallel agentic work, not for handoff between humans.
5. **Don't build features no one's asked for.** Validate with clients before scope expansion.

---

## Contact / context for next conversation

If you're picking this up in a new chat:
- Read this brief, then `ARCHITECTURE.md`, then `DECISIONS.md`, then `SCHEMA_SPEC.md`
- Andrew is the owner, non-technical, comfortable in PowerShell with guidance
- The project is built primarily by orchestrating 2-3 parallel Claude Code instances
- This document was co-written by Andrew and Claude (Opus 4.7) on day 1 of the build
- Treat the strategic questions as already-decided unless explicitly reopened

---

**End of brief.**
