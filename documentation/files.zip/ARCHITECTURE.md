# Trailblaze Analytics — Architecture

**Companion to `PROJECT_BRIEF.md`. Read that first.**

---

## High-level system view

```mermaid
flowchart TB
    subgraph Sources["DATA SOURCES"]
        PDF["📄 Trailblaze PDFs<br/>~307 historical<br/>+1/day ongoing"]
        REG["🏛️ State regulators<br/>NJ, PA, MI, CT, IL"]
        STOCK["📈 Stock data<br/>(yfinance)"]
        SEC["📋 SEC filings<br/>(future)"]
        SOCIAL["💬 Social sentiment<br/>(future)"]
    end

    subgraph Ingest["INGEST LAYER (Python)"]
        PARSER["PDF Parser<br/>Anthropic Claude<br/>Two-pass extraction"]
        REGSCRAPE["Regulator scrapers<br/>BeautifulSoup4"]
        STOCKING["Stock ingester<br/>yfinance"]
        BEACON["🔥 Beacon™ Engine<br/>Modeled estimates<br/>(later phase)"]
    end

    subgraph DB["DATABASE LAYER"]
        PG[("PostgreSQL 16<br/>15 tables<br/>materialized views")]
    end

    subgraph App["PRESENTATION LAYER (Next.js)"]
        AUTH["Supabase Auth<br/>Magic link"]
        UI["Dashboard UI<br/>Dark mode<br/>Bloomberg-style"]
        API["Server Components<br/>Direct SQL queries"]
    end

    subgraph Users["USERS"]
        BANK["💼 Investment banks"]
        FUND["📊 Hedge funds / PE"]
        OPS["🎰 Operator BD teams"]
    end

    PDF --> PARSER
    REG --> REGSCRAPE
    STOCK --> STOCKING
    PARSER --> PG
    REGSCRAPE --> PG
    STOCKING --> PG
    BEACON --> PG
    PG --> API
    API --> UI
    AUTH --> UI
    UI --> BANK
    UI --> FUND
    UI --> OPS
```

---

## Data model — entity relationships

```mermaid
erDiagram
    REPORTS ||--o{ REPORT_ENTITIES : "covers"
    REPORTS ||--o{ REPORT_MARKETS : "covers"
    REPORTS ||--o{ METRIC_VALUES : "produces"
    REPORTS ||--o{ NARRATIVES : "contains"

    ENTITIES ||--o{ ENTITY_TYPE_ASSIGNMENTS : "is"
    ENTITY_TYPES ||--o{ ENTITY_TYPE_ASSIGNMENTS : "categorizes"
    ENTITIES ||--o{ ENTITIES : "parent of"
    ENTITIES ||--o{ METRIC_VALUES : "subject of"
    ENTITIES ||--o{ REPORT_ENTITIES : "mentioned in"

    MARKETS ||--o{ MARKETS : "parent of"
    MARKETS ||--o{ METRIC_VALUES : "context for"
    MARKETS ||--o{ MARKET_TAX_HISTORY : "has"
    MARKETS ||--o{ REPORT_MARKETS : "mentioned in"

    METRICS ||--o{ METRIC_VALUES : "defines"
    PERIODS ||--o{ METRIC_VALUES : "time-stamps"
    SOURCES ||--o{ METRIC_VALUES : "originates"
    SOURCES ||--o{ REPORTS : "categorizes"

    METRIC_VALUES ||--o| BEACON_ESTIMATES : "audit"

    METRIC_VALUE_CANONICAL }o--|| METRIC_VALUES : "picks best"
    METRIC_VALUE_DISCREPANCIES }o--|| METRIC_VALUES : "flags conflicts"
```

---

## Parser flow (per PDF)

```mermaid
flowchart LR
    A[📄 PDF arrives] --> B{Already parsed?<br/>SHA-256 hash}
    B -->|Yes| Z[Skip - idempotent]
    B -->|No| C[Extract text<br/>pypdf]
    C --> D{Text < 2000 chars?}
    D -->|Yes| E[Mark as shell<br/>parse_status=parsed_shell]
    D -->|No| F[Pass 1: Classify<br/>Claude API]
    F --> G[Identify entities,<br/>markets, period,<br/>doc type]
    G --> H[Pass 2: Extract<br/>Claude API]
    H --> I[Get all metrics<br/>+ narratives]
    I --> J{Validation passes?}
    J -->|No| K[Log warning,<br/>mark with_warnings]
    J -->|Yes| L[Insert into DB:<br/>metric_values<br/>narratives<br/>report_entities<br/>report_markets]
    K --> L
    L --> M[Refresh canonical view]
    M --> N[✅ Complete]
    E --> N
```

---

## Frontend page structure

```mermaid
flowchart TD
    LOGIN["/login<br/>Magic link"] --> HOME

    HOME["/<br/>Home + Search"]

    HOME --> MARKETS["/markets<br/>Index"]
    HOME --> COMPANIES["/companies<br/>Index"]
    HOME --> REPORTS_LIST["/reports<br/>Recent feed"]
    HOME --> METHODOLOGY["/methodology<br/>Beacon™ explained"]

    MARKETS --> MARKET_DETAIL["/markets/[slug]<br/>e.g. /markets/us-new-jersey"]
    MARKETS --> MARKET_COMPARE["/markets/compare?slugs=..."]

    COMPANIES --> COMPANY_DETAIL["/companies/[slug]<br/>e.g. /companies/flutter"]
    COMPANIES --> COMPANY_COMPARE["/companies/compare?slugs=..."]

    REPORTS_LIST --> REPORT_DETAIL["/reports/[id]<br/>Original metrics + narratives"]

    MARKET_DETAIL -.->|drill into| COMPANY_DETAIL
    COMPANY_DETAIL -.->|drill into| MARKET_DETAIL
```

---

## Provenance and Beacon™ flagging

Every value in the database knows its source. The dashboard shows this visually:

```mermaid
flowchart LR
    subgraph Sources["Source types (precedence)"]
        A1["1. Trailblaze PDF<br/>(disclosed)"]
        A2["2. Regulator filing<br/>(verified)"]
        A3["3. SEC / Co. IR<br/>(verified)"]
        A4["4. Stock API<br/>(verified)"]
        A5["5. Industry trade<br/>(medium)"]
        A6["6. Trailblaze Beacon™<br/>(modeled)"]
    end

    subgraph View["Canonical view picks one"]
        B[metric_value_canonical<br/>materialized view]
    end

    subgraph Display["Dashboard rendering"]
        C1["Solid line / clean number<br/>= disclosed"]
        C2["Dotted line / ™ superscript<br/>= Beacon™"]
        C3["em-dash<br/>= not_disclosed"]
        C4["⚠️ badge<br/>= discrepancy between sources"]
    end

    A1 --> B
    A2 --> B
    A3 --> B
    A4 --> B
    A5 --> B
    A6 --> B
    B --> C1
    B --> C2
    B --> C3
    B --> C4
```

---

## Production deployment topology (target)

```mermaid
flowchart TB
    subgraph User["User browser"]
        BROWSER["Browser<br/>analytics.trailblaze-marketing.com"]
    end

    subgraph Vercel["Vercel"]
        NEXT["Next.js app<br/>(static + SSR)"]
    end

    subgraph Neon["Neon (Managed Postgres)"]
        PROD_DB[("Production Postgres<br/>Read replica for dashboard<br/>Write replica for ingest")]
    end

    subgraph Railway["Railway (background workers)"]
        DAILY_INGEST["Daily PDF ingest<br/>cron: every hour<br/>SSH to reporting server"]
        WEEKLY_STOCKS["Weekly stock refresh<br/>cron: Sundays"]
        MONTHLY_REGS["Monthly regulator scrape<br/>cron: 2nd of month"]
    end

    subgraph SourceServers["Source servers (existing)"]
        REPORTING["reporting.trailblaze-marketing.com<br/>(MODX CMS, PDFs land here)"]
    end

    BROWSER --> NEXT
    NEXT --> PROD_DB
    DAILY_INGEST --> REPORTING
    DAILY_INGEST --> PROD_DB
    WEEKLY_STOCKS --> PROD_DB
    MONTHLY_REGS --> PROD_DB
```

---

## Why these choices

See `DECISIONS.md` for the rationale behind each major architectural choice.

---

## Local development topology (current)

Right now, everything runs on Andrew's PC:

```mermaid
flowchart TB
    subgraph PC["Andrew's PC (local dev)"]
        TERMINALS["3 PowerShell windows<br/>each running Claude Code"]

        subgraph PYBACK["Python backend"]
            PARSER_LOCAL["PDF Parser<br/>Anthropic API"]
            SCRAPERS_LOCAL["Scrapers<br/>(in build)"]
        end

        subgraph PG_LOCAL["PostgreSQL 16<br/>localhost:5432"]
            DB_LOCAL[("trailblaze database<br/>15 tables, seeded")]
        end

        subgraph WEB["Next.js frontend"]
            WEB_LOCAL["web/ folder<br/>(in build)<br/>localhost:3000"]
        end

        TERMINALS --> PARSER_LOCAL
        TERMINALS --> SCRAPERS_LOCAL
        TERMINALS --> WEB_LOCAL
        PARSER_LOCAL --> DB_LOCAL
        SCRAPERS_LOCAL --> DB_LOCAL
        WEB_LOCAL --> DB_LOCAL
    end

    PARSER_LOCAL -.calls.-> ANTHROPIC["Anthropic API<br/>(Claude Opus 4.7)"]
    PARSER_LOCAL -.SSH pulls PDFs.-> REMOTE["reporting.trailblaze-marketing.com<br/>(307 PDFs)"]
```

---

**End of architecture doc.**
