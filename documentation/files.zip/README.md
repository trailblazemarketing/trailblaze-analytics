# Trailblaze Analytics

> **The iGaming intelligence platform.**
>
> Structured, queryable data + AI-extracted insights + proprietary Trailblaze Beacon™ estimates, all in one dashboard.

---

## What's in this folder

| File | What it is |
|---|---|
| `README.md` | This file — start here |
| `PROJECT_OVERVIEW.md` | Vision, three buckets, business model, brand |
| `ARCHITECTURE.md` | System architecture with diagrams |
| `SCHEMA_SPEC.md` | Database schema spec (the build blueprint) |
| `src/trailblaze/` | Python backend (parser, scrapers, DB) |
| `web/` | Next.js dashboard frontend |
| `pdfs/` | Local PDF cache (307 files) |
| `alembic/` | Database migration files |
| `deploy/` | Hosting configurations |

---

## Reading order

**If you're new to the project:**
1. Read `PROJECT_OVERVIEW.md` to understand the vision
2. Read `ARCHITECTURE.md` to understand how it's built
3. Refer to `SCHEMA_SPEC.md` when working on the database

**If you're a developer joining:**
1. `ARCHITECTURE.md`
2. `SCHEMA_SPEC.md`
3. Run the local dev setup below

---

## Local development setup

### Prerequisites

- Windows / Mac / Linux
- Python 3.13+
- PostgreSQL 16
- Node.js 22+ (for the frontend)
- An Anthropic API key

### Backend setup

```bash
# Create virtualenv
python -m venv .venv
.venv\Scripts\activate    # Windows
# source .venv/bin/activate    # Mac/Linux

# Install dependencies
pip install -e .

# Set environment variables
cp .env.example .env
# Edit .env — add your ANTHROPIC_API_KEY and DATABASE_URL

# Apply database migrations
alembic upgrade head

# Seed reference data
python -m trailblaze.seed.run

# Test the parser on one PDF
trailblaze-parse pdfs/<some-file>.pdf
```

### Frontend setup

```bash
cd web/
npm install
cp .env.local.example .env.local
# Edit .env.local — add Supabase credentials and DATABASE_URL
npm run dev
# Visit http://localhost:3000
```

---

## CLI commands

| Command | What it does |
|---|---|
| `trailblaze-parse <pdf>` | Parse a single PDF into the database |
| `trailblaze-parse-batch <dir>` | Parse all PDFs in a directory |
| `trailblaze-seed` | Re-run seed data (idempotent) |
| `trailblaze-scrape-regulators` | Pull data from regulator websites |
| `trailblaze-scrape-stocks` | Pull stock prices for tickered entities |

---

## Project status

**Currently in active build (April 2026).**

| Phase | Status |
|---|---|
| Schema design | ✅ Complete |
| Database + parser | 🟡 In progress |
| Frontend dashboard | 🟡 In progress |
| External scrapers | 🟡 In progress |
| Beacon™ engine | ⏳ Planned |
| Business Planner | ⏳ Planned |
| Production deploy | ⏳ Planned |

See `PROJECT_OVERVIEW.md` for the full phase breakdown.

---

## Trailblaze Beacon™

When data isn't disclosed anywhere, the platform estimates it using a transparent, defensible methodology — branded as **Trailblaze Beacon™**. See `ARCHITECTURE.md` § "Beacon™ engine flow" for how it works.

In the dashboard, Beacon™ values appear with:
- Dotted lines on time-series charts
- ™ superscript next to numbers
- Confidence bands shaded around estimates
- Hover card explaining the methodology used and inputs consumed

---

## Built with

Python · PostgreSQL · Anthropic Claude · Next.js · TypeScript · Tailwind · shadcn/ui · Recharts · TanStack Table · Supabase Auth · Vercel · Neon · Railway

---

**Owner:** Trailblaze Marketing
**Contact:** info@trailblaze-marketing.com
