# Trailblaze Analytics — Decisions Log

**Companion to `PROJECT_BRIEF.md`. Read that first.**

This document captures the *why* behind every major decision. If you're tempted to relitigate any of these, read the rationale first. If the rationale no longer holds, then change it — but consciously, not accidentally.

---

## Product positioning

### D1: Why iGaming and not a more general "intelligence platform"
- Trailblaze Marketing has 20+ years of domain expertise here
- Existing daily content engine (the PDFs) provides natural data moat
- iGaming is fragmented, growing, under-served by tooling, and full of public-market actors who pay for data
- A generic "industry intelligence" play has no defensible angle; a vertical-specific one does

### D2: "iGaming" not "gambling"
- Banks have policies against funding "gambling" but most accept "iGaming"
- Existing sector convention — H2GC, VIXIO, EGR all use "iGaming"
- Reduces friction for sales and payments

### D3: Three buckets — Markets, Companies (with sub-types), Beacon™ as cross-cutting feature
- Considered making Affiliates a top-level bucket
- Decided against because affiliates ARE companies, just a sub-type
- Cleaner mental model: 2 noun buckets (markets, companies) + 1 cross-cutting brand asset (Beacon™)

---

## Brand & product asset decisions

### D4: "Trailblaze Beacon™" as the name for modeled estimates
- Considered: Trailblaze Estimate, TrailblazeIQ, Trailblaze Insight, Blaze Number, Implied, Inferred, Mark, Index
- Picked Beacon™ because:
  - Thematically locked to "Trailblaze" (beacons guide trailblazers)
  - One word — ownable, brandable, memorable
  - Doesn't sound apologetic the way "Estimate" does
  - Has visual potential (literal beacon icon in UI)
  - Unique enough to trademark

### D5: Beacon™ flagged everywhere visually
- Dotted chart lines (vs solid for disclosed)
- ™ superscript on numbers
- Hover card explains methodology
- Color: amber/gold (`#F59E0B`) to draw eye without alarm
- This is a feature, not a footnote — the brand asset has to be visible

---

## Architectural decisions

### D6: PostgreSQL over SQLite/MongoDB/etc.
- jsonb support (we use it for `metadata` columns)
- Materialized views (canonical value picker)
- GIN indexes for full-text search across narratives
- Industry standard, easy to find help, portable to any host
- SQLite would have worked for v1 but would force migration later

### D7: Postgres native install, not Docker (LOCAL ONLY)
- Tried Docker Desktop, blocked by missing WSL2 on Andrew's PC
- Choice was: install WSL2 (yet another reboot) OR install Postgres natively
- Picked native to avoid the friction
- Production will use managed Postgres anyway (Neon/Supabase) so this doesn't matter long-term
- If a developer joins, they'd want Docker on their machine

### D8: Long-format `metric_values` table (one row per fact)
- Considered wide-format (column per metric)
- Rejected because metrics list is open-ended and grows
- Long-format makes time-series queries trivial, comparison queries clean
- Trade-off: more rows. Postgres handles tens of millions easily.

### D9: Multiple values per (entity, market, metric, period) is allowed
- Same Q3 metric can appear in: the report PDF, the presentation PDF, the trading update, a regulator filing, a Beacon™ estimate
- All five rows are saved
- A `metric_value_canonical` materialized view picks the "best" by precedence
- Discrepancies between sources are flagged in `metric_value_discrepancies`
- This is more complex than naïve dedup but it's the only way to handle real-world reporting

### D10: Provenance is a first-class column, not metadata
- Every value has `source_id` pointing to the source type
- `disclosure_status` distinguishes disclosed / not_disclosed / Beacon™ / derived
- `confidence_score` for parser confidence + Beacon™ model confidence
- Why: financial clients will absolutely ask "where did this number come from?" The platform must answer instantly.

### D11: Hierarchical entities (parent_entity_id self-ref) and hierarchical markets
- Entities: Allwyn → PrizePicks → individual brand
- Markets: North America → US → New Jersey
- Self-referential FK is simple and queryable
- Allows roll-up views and drill-downs

### D12: Document type taxonomy on reports
- Not all PDFs are the same shape — earnings reports, presentations, trading updates, CMDs, M&A announcements, market updates, shells
- The classifier identifies the type; the parser uses different extraction logic per type
- Important because a "presentation" version of Q3 may have slightly different numbers than the "report" version — provenance includes type

---

## Build process decisions

### D13: Build with Claude Code, orchestrate with Claude Opus (this conversation)
- Andrew is non-technical. Manual coding would take 6+ months.
- Claude Code does the engineering. Claude Opus (this chat) is the strategist + project manager + translator.
- Estimated cost saving vs hiring a small dev team: £80k–£150k.
- Estimated time saving: months → days.

### D14: Run multiple Claude Code instances in parallel
- One terminal can only do one thing at a time
- Backend, frontend, and scrapers are independent enough to parallelize
- Capped at 3 simultaneous instances — more is too much cognitive load on the human + risks API rate limits
- Each instance gets a clear "don't touch X folder" instruction to avoid file conflicts

### D15: Auto-approve read-only commands, manually approve writes
- Read-only commands (`ls`, `cat`, `grep`, etc.) are safe and frequent — auto-approve
- Anything writing files, modifying `.env`, or making external API calls gets explicit approval
- Maintains safety without slowing down 90% of routine work

### D16: Schema spec written FIRST, before any code
- 22-page markdown doc (`SCHEMA_SPEC.md`) specifies the entire data model
- Claude Code implements from spec, not from vague intent
- Reduces back-and-forth, produces consistent code, makes the spec the source of truth
- Lesson: even AI-led builds benefit from a clear spec doc

### D17: Git commit at every milestone
- First commit captured the entire scaffold so we can roll back to it
- Future commits at each major stage boundary
- This is non-negotiable safety, regardless of who/what is writing the code

---

## Frontend decisions

### D18: Next.js App Router, not Pages Router
- App Router is the future, RSC by default = better performance
- Direct DB queries from server components — no API layer needed for v1
- Cleaner code, smaller bundle

### D19: Tailwind + shadcn/ui, not a heavy component library (MUI, Ant)
- Smaller bundle, more control, dark-mode native
- shadcn primitives are copy-paste, not a dependency — full ownership
- Modern aesthetic out of the box

### D20: Build "everything", not an MVP
- Andrew explicitly chose this — "fuck MVP, ship everything"
- Counterargued by AI strategist: stagger the release for better feedback + marketing moments
- Compromise reached: build full architecture, ship in weekly waves to a small client list
- Current plan: full app built, but soft-launched to ~5 friendly users first

### D21: Auth separate from existing portal (`reporting.trailblaze-marketing.com`)
- Existing portal uses MODX-managed users
- New analytics dashboard uses Supabase Auth (magic link)
- Same person may need 2 logins for now
- Single sign-on consolidation is a later phase

---

## Data sourcing decisions

### D22: Treat the PDFs as the source of truth, not the upstream emails
- Andrew doesn't have access to the email source the PDFs are generated from
- The PDFs ARE the artifact, however imperfect
- Build the system around them, with quality flagging for shells/empties
- Long-term: improve the upstream email-to-PDF pipeline OR cut out the middleman entirely

### D23: Start with state regulators, expand later
- US states have public, structured monthly data — easy to scrape, high value
- NJ, PA, MI, CT, IL = the 5 with the most analytical demand
- Other states + non-US regulators added as the user base demands

### D24: yfinance for stock data, not paid feeds
- Free, sufficient for v1 (delayed quotes are fine for an analytics dashboard)
- Switch to a paid feed (Polygon, Alpha Vantage, etc.) only if real-time becomes a feature

### D25: Web scraping limited to clearly-public sources for v1
- Regulators (clearly public)
- SEC filings (clearly public)
- Stock APIs (licensed via the API itself)
- Industry trades (iGB, EGR) — deferred until we have RSS or paid syndication, to avoid TOS issues
- Social sentiment — deferred until clear use case

---

## Operational decisions

### D26: Daily PDF ingest = cron job, not webhook
- Webhook would require modifying the existing reporting server
- Cron polling every hour is simpler and reliable
- Trade-off: up to 1 hour delay between PDF upload and dashboard refresh — acceptable

### D27: API key rotation policy
- Andrew accidentally exposed the first Anthropic API key in a paste during the build
- Lesson: rotate immediately if exposed (minutes-cheap fix)
- Never paste keys in chat/email/Slack — use password manager share or one-time secret services
- Future automation: add a script to rotate keys on a schedule (later phase)

### D28: Beacon™ engine deferred to phase 2
- Schema supports it from day 1 (`beacon_estimates` table)
- Engine itself isn't built yet — too much complexity for day 1
- Build sequence: dashboard first (proves the data + UX), then Beacon™ (adds the moat)

### D29: Methodology page is required before Beacon™ values are exposed publicly
- Legal/credibility risk if clients can see Beacon™ values without a methodology explanation
- The page must be defensible — "where did this number come from" needs a real answer
- Engaged a professional copywriter optional but recommended

---

## What we deliberately said NO to

- **Crypto integration** — narrowing focus, not expanding it
- **Mobile-first design** — desktop-first because the audience uses desktop
- **AI chat interface inside the dashboard** — easy to add later, distracting if added now
- **User-generated content (comments, ratings)** — not relevant for a B2B analytics product
- **Free tier with ads** — wrong business model for this audience
- **Multi-language UI** — English-only for v1; Spanish/Portuguese later if LatAm clients demand

---

## Reconsidering decisions

A decision is settled when:
1. It's documented here
2. It's been followed for at least 2 weeks of build
3. We've encountered the problem it solves at least once

A decision should be reopened when:
1. The original constraint that drove it has changed (e.g. WSL2 becomes available, so Docker is back on the table)
2. A bigger problem appears that the original choice causes
3. A user explicitly asks for something the choice prevents

Don't reopen decisions just because someone (or some AI) thinks "we could do it better." The cost of relitigating is real.

---

**End of decisions log.**
